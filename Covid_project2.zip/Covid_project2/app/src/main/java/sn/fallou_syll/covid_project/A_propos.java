package sn.fallou_syll.covid_project;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class A_propos extends menu {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_a_propos);
    }
}